package test;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.junit.Test;

public class Tech2 {

	public static void main (String... args) {
		String strTest = "# Asdf";
		System.out.println(markupHeaders(strTest));
	}

	public static String markupHeaders(String strText) {
		String strResult = markupHeaders(strText, 1);
		strResult = markupHeaders(strResult, 2);
		strResult = markupHeaders(strResult, 3);
		strResult = markupHeaders(strResult, 4);
		strResult = markupHeaders(strResult, 5);
		strResult = markupHeaders(strResult, 6);
		return strResult;	
	}

	private static String markupHeaders(String strText, int hashNumbers) {
		String strPattern = "^([ ]{0,})(#{" + hashNumbers + "}(?!#))([ ])(.*)";
		Matcher m = Pattern.compile(strPattern).matcher(strText);
		if(m.find()){
			return m.replaceFirst("<h"+hashNumbers+">$4</h"+hashNumbers+">");
		}
		return strText;
	}
	
	@Test
	public void testConvertedAll(){
		StringBuilder sb = new StringBuilder();
		for(int i=1; i<=6; i++){
			sb.append("#");
			StringBuilder strInitText = new StringBuilder(sb.toString()).append(" My Heading");
			String strResultText = markupHeaders(strInitText.toString());
			Assert.assertEquals("<h"+i+">My Heading</h"+i+">", strResultText);
		}
		
	}
	
	@Test
	public void testSpacesTrimmed(){
		String strInitText = " #### Heading4 Something here asdf  ### asdf";
		String strResultText = markupHeaders(strInitText);
		Assert.assertEquals("<h4>Heading4 Something here asdf  ### asdf</h4>", strResultText);
	}
	
	@Test
	public void testSpacesNoSpaceAfterHash(){
		String strInitText = " ###NoSpace after Hash";
		String strResultText = markupHeaders(strInitText);
		Assert.assertEquals(strInitText, strResultText);
	}
	
	@Test
	public void testRegularString(){
		String strInitText = " Regular string";
		String strResultText = markupHeaders(strInitText);
		Assert.assertEquals(strInitText, strResultText);
	}
}	