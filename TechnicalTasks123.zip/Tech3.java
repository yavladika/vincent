package test;

import org.junit.Assert;
import org.junit.Test;

public class Tech3 {
	public static void main(String... args){
		int n = getNumberFirstShift("SERGHEI", "HEISERG");
		System.out.println("STRING ROTATION: " + n);
	}
	
	/**
	 * Getting the shift number of the first string compared to second. -1 in case no match found
	 * @param first - first string to compare
	 * @param second - second string to compare to
	 * @return -1 in case no match found. Otherwise number of shifts of the characters to the right
	 */
	public static int getNumberFirstShift(String first, String second){
		int shiftsRequired = -1;
		StringBuilder sbFirst = new StringBuilder(first);
		
		StringBuilder sbTempDoubled = sbFirst.append(sbFirst);
		if(sbTempDoubled.toString().contains(second)){
			return getShiftedNumber(first, second);
		}
		
		return shiftsRequired;
	}
	
	/**
	 * returns number of shifts in string which we know for sure have match
	 * @param first - first string
	 * @param second - second string
	 * @return number of shifts
	 */
	public static int getShiftedNumber(String first, String second){
		int shiftsRequired = -1;
		if(first.equals(second)){
			return 0;
		}
		
		StringBuilder sbFirst;
		int firstLength = first.length();
		for(int i=1; i<firstLength; i++){
			sbFirst = new StringBuilder(first.substring(firstLength-i, firstLength)).append(first.substring(0, firstLength-i));
			if(second.equals(sbFirst.toString())){
				return i;
			}
		}
		
		return shiftsRequired;
	}
	
	@Test
	public void testScenarios(){
		String stringFirst = "coffee";
		String stringSecond = "eecoff";
		Assert.assertEquals(2, getNumberFirstShift(stringFirst, stringSecond));
		
		stringFirst = "eecoff";
		stringSecond = "coffee";
		Assert.assertEquals(4, getNumberFirstShift(stringFirst, stringSecond));
		
		stringFirst = "moose";
		stringSecond = "Moose";
		Assert.assertEquals(-1, getNumberFirstShift(stringFirst, stringSecond));
		
		
		stringFirst = "isn't";
		stringSecond = "'tisn";
		Assert.assertEquals(2, getNumberFirstShift(stringFirst, stringSecond));
		
		
		stringFirst = "Esham";
		stringSecond = "Esham";
		Assert.assertEquals(0, getNumberFirstShift(stringFirst, stringSecond));
		
		stringFirst = "dog";
		stringSecond = "god";
		Assert.assertEquals(-1, getNumberFirstShift(stringFirst, stringSecond));
	}
}
