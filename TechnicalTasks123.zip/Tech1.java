package test;

import java.util.Arrays;

import org.junit.Assert;
import org.junit.Test;


public class Tech1 {
	public static int MAX_CHARS_AVAILABLE = 256;

	public static void main(String[] args) {
		String myString = "str";
		System.out.println("Is Unique: "+ checkUnique(myString) );
	}
	
	/**
	 * Checks for unique character in a string
	 * @param str
	 * @return true if all characters are unique
	 */
	public static boolean checkUnique(String str){
        if (str.length() > MAX_CHARS_AVAILABLE){ 
            return false; 
        }
  
        boolean[] charsUniqode = new boolean[MAX_CHARS_AVAILABLE]; 
        Arrays.fill(charsUniqode, false); 
  
        for (int i = 0; i < str.length(); i++) { 
            int index = str.charAt(i); 
  
            if (charsUniqode[index] == true){ 
                return false; 
            }
            charsUniqode[index] = true; 
        } 
  
        return true; 
	}
	
	@Test
	public void testUniqueStringTrue(){
		String sUnique = "ser gdlf543(&$#DF|}";
		boolean bUnique = checkUnique(sUnique);
		Assert.assertEquals(true, bUnique);
	}
	
	@Test
	public void testUniqueStringFalse(){
		String sUnique = "ddf";
		boolean bUnique = checkUnique(sUnique);
		Assert.assertEquals(false, bUnique);
	}
	
	@Test
	public void testUniqueSpaces(){
		String sUnique = "ser gdl f543(&$#DF|}";
		boolean bUnique = checkUnique(sUnique);
		Assert.assertEquals(false, bUnique);
	}

}
