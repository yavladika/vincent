package test;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BinaryOperator;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MergeMaps {
	public static void main(String[] args) {
		Map<String, Integer> m1 = new HashMap<>();
		Map<String, Integer> m2 = new HashMap<>();
		String strKey1 = "key1";
		String strKey2 = "key2";
		String strKey3 = "key3";
		String strKey4 = "key1";

		m1.put(strKey1, 20);
		m1.put(strKey2, 30);
		m2.put(strKey3, 40);
		m2.put(strKey4, 50);	
		
		System.out.println("Initial Map m1: " + m1);
		System.out.println("Initial Map m2: " + m2);
		System.out.println();
		
		Map<String, Integer> concatMap = mergeTheMaps(m1, m2, (a,b)->a+b);
		
		System.out.println("Merging Maps: " + concatMap);
		
		//------------------------------------------------------
		
		List<Map<String, Integer>> listOfMaps = new ArrayList<>(Arrays.asList(m1, m2));
		Map<String, Integer> parallelListMap = mergeTheListOfMaps(listOfMaps, HashMap::new, (a,b)->a+b);
		
		System.out.println("Merging List of Maps: " + parallelListMap);
	}
	
	/**
	 * Concatenating maps
	 * @param m1
	 * @param m2
	 * @param mergeFunction
	 * @return
	 */
	public static <K,V> Map<K,V> mergeTheMaps(Map<K, V> m1, Map<K,V> m2, BinaryOperator<V> mergeFunction){
		return Stream.of(m1, m2).map(Map::entrySet).flatMap(Collection::stream).collect(Collectors.toMap( Map.Entry::getKey, Map.Entry::getValue, mergeFunction));
	}
	
	/**
	 * Concatenating list of maps in parallel stream
	 * @param lists
	 * @param mapSupplier
	 * @param mergeFunction
	 * @return
	 */
	public static <K, V, M extends Map<K, V>> M mergeTheListOfMaps(List< Map<K,V> > lists, Supplier<M> mapSupplier, BinaryOperator<V> mergeFunction){
		return lists.parallelStream().collect(mapSupplier,
				(a, b) -> b.forEach((k, v) -> a.merge(k, v, mergeFunction)), 
				(a, b) -> b.forEach((k, v) -> a.merge(k, v, mergeFunction)));
	}
	
}
