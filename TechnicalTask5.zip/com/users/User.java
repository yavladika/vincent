package com.users;

import java.util.Date;

import com.comments.Comment;

public class User implements IUser {
	
	protected long userId = userCounter.incrementAndGet();
	protected String userName;
	protected Date lastLogin = new Date();
	
	public User(String userName) {
		this.userName = userName;
	}
	
	/**
	 * User can Edit his comments only
	 */
	@Override
	public Comment editComment(Comment comment, String newComment) {
		if(comment.getuserCommentOwner().userId == this.userId) {
			comment.setCommentData(newComment);
		}
		return comment;
	}
	
	/**
	 * User can delete replies to his comments only.
	 */
	@Override
	public Comment deleteComment(Comment commentToDelete) {
		Comment commentRepliedTo = commentToDelete.getParentCommentRepliedTo();
		if(commentRepliedTo != null ){
			if(commentRepliedTo.getuserCommentOwner().getUserId() == this.userId) {
				commentToDelete = null;
				return null;
			}
		}
		return commentToDelete;
	}
	
	
	
	
	//----------------------------------
	/**
	 * User can create comments
	 */
	@Override
	public Comment createComment(String strComment) {
		Comment comment = new Comment(strComment);
		comment.setUserCommentOwner(this);
		return comment;
	}
	
	/**
	 * User can reply to other comments
	 */
	@Override
	public Comment replyToComment(Comment commentToReplyTo, Comment newChildComment) {
		commentToReplyTo.setChildRepliedComment(newChildComment);
		newChildComment.setParentCommentRepliedTo(commentToReplyTo);
		newChildComment.setRepliedTo(commentToReplyTo.getuserCommentOwner());
		return newChildComment;
	}
	
	@Override
	public long getUserId() {
		return userId;
	}
	
	@Override 
	public String getUserName() {
		return userName;
	}
	
	@Override
	public Date getLastLogin() {
		return lastLogin;
	}
	
	@Override 
	public Date login() {
		lastLogin = new Date();
		return lastLogin;
	}
	
	@Override 
	public Date logout() {
		return new Date();
	}
}
