package com.users;

import com.comments.Comment;

public class ModeratorUser extends User {
	
	public ModeratorUser(String userName) {
		super(userName);
	}
	
	/**
	 * Moderator can delete any comment
	 */
	@Override
	public Comment deleteComment(Comment commentToDelete) {
		commentToDelete = null;
		return null;
	}
}
