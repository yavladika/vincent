package com.users;

import java.util.Date;
import java.util.concurrent.atomic.AtomicLong;

import com.comments.Comment;

public interface IUser {
	public static final AtomicLong userCounter = new AtomicLong();
	
	public Comment createComment(String strComment);
	public Comment editComment(Comment comment, String strNewComment);
	public Comment deleteComment(Comment replyComment);
	
	public Comment replyToComment(Comment commentToReplyTo, Comment newChildComment);
	
	public long getUserId();
	public String getUserName();
	public Date getLastLogin();
	public Date login();
	public Date logout();
	
}
