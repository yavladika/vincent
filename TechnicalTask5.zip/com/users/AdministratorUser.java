package com.users;

import com.comments.Comment;

public class AdministratorUser extends ModeratorUser {
	public AdministratorUser(String userName) {
		super(userName);
	}
	
	/**
	 * Admin can Edit any comment
	 */
	@Override
	public Comment editComment(Comment comment, String newComment) {
		comment.setCommentData(newComment);
		return comment;
	}
}
