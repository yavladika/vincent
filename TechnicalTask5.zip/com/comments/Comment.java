package com.comments;

import java.util.concurrent.atomic.AtomicLong;

import com.users.User;

public class Comment {
	protected final AtomicLong commentCounter = new AtomicLong();
	
	protected User userCommentOwner;
	protected User repliedTo;
	protected String commentData;
	
	/** in case it is a reply to a parent comment -> this will not be null*/
	protected Comment parentCommentRepliedTo;
	
	/** in case there are replies to this comment -> this will not be null */
	protected Comment childRepliedComment;
	
	public Comment() {
		
	}
	
	public Comment(String comment){
		this.commentData = comment;
	}
	
	public void setUserCommentOwner(User owner) {
		this.userCommentOwner = owner;
	}
	
	public User getuserCommentOwner() {
		return userCommentOwner;
	}
	
	public User getRepliedTo() {
		return repliedTo;
	}

	public void setRepliedTo(User repliedTo) {
		this.repliedTo = repliedTo;
	}

	public String getCommentData() {
		return commentData;
	}

	public void setCommentData(String commentData) {
		this.commentData = commentData;
	}

	public Comment getParentCommentRepliedTo() {
		return parentCommentRepliedTo;
	}

	public void setParentCommentRepliedTo(Comment parentCommentRepliedTo) {
		this.parentCommentRepliedTo = parentCommentRepliedTo;
	}
	
	

	public Comment getChildRepliedComment() {
		return childRepliedComment;
	}

	public void setChildRepliedComment(Comment childRepliedComment) {
		this.childRepliedComment = childRepliedComment;
	}

	public String toString() {
		StringBuffer toStringComment = new StringBuffer();
		if(userCommentOwner != null) {
			toStringComment = new StringBuffer(commentData).append(" by ").append(userCommentOwner.getUserName());
			if(repliedTo != null) {
				return toStringComment.append(" replied to ").append(repliedTo.getUserName()).toString();
			}
		}
		return toStringComment.toString();
	}
	
	
	
}
