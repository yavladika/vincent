import java.util.Timer;

import com.comments.Comment;
import com.users.AdministratorUser;
import com.users.IUser;
import com.users.ModeratorUser;
import com.users.User;

public class Application {

	public static void main(String[] args) {
		
		IUser regularUser = new User("Alex");
		IUser moderatorUser = new ModeratorUser("John");
		IUser adminUser = new AdministratorUser("Peter");

		Comment regUserComment = regularUser.createComment("Comment Data By regular user ");
		System.out.println(regUserComment);
		
		regUserComment = regularUser.editComment(regUserComment, "MY NEW EDITED COMMENT BY SAME REGULAR USER");
		System.out.println(regUserComment);
		
		regUserComment = regularUser.deleteComment(regUserComment);

		System.out.println("Comment could not be deleted: " + regUserComment);
		
		regUserComment = moderatorUser.editComment(regUserComment, "NEW COMENT SHOULD NOT BE EDITED");
		
		System.out.println(regUserComment);
		
		regUserComment = adminUser.editComment(regUserComment, "NOW SHOW EDITION BY ADMIN HERE");
		
		System.out.println(regUserComment);
		
		Comment adminUserComment = adminUser.createComment("ADMIN USER COMMENT");
		adminUserComment = adminUser.replyToComment(regUserComment, adminUserComment);
		
		
		regUserComment = moderatorUser.deleteComment(regUserComment);
		
		System.out.println("Comment deleted by admin: " + regUserComment);
		
		System.out.println(adminUserComment);
		
		System.out.println();
		System.out.println();
		System.out.println("LastLogin before logout: "+regularUser.getLastLogin());
		try {
			Thread.sleep(1000);
		}catch(InterruptedException e) {
			
		}
		regularUser.logout();
		regularUser.login();
		System.out.println("LastLogin after login: " + regularUser.getLastLogin());
		
		
	}

}
