package com.amdocs.model;

import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

public class ArticleDAO {
	private final AtomicLong idCounter = new AtomicLong();
	
		private static List<Article> articles;
		{
			articles = new ArrayList<Article>();
			articles.add(new Article(idCounter.incrementAndGet(), "Default Title1", "Default Article about FIRST DATA"));
			articles.add(new Article(idCounter.incrementAndGet(), "Default Title2", "Default Article about SECOND DATA"));
			articles.add(new Article(idCounter.incrementAndGet(), "Default Title3", "Default Article about THIRD DATA"));
		}

		/**
		 * Returns list of articles from memory.
		 * 
		 * @return list of articles
		 */
		public List<Article> list() {
			return articles;
		}

		/**
		 * Return article object for given id from memory. If article is
		 * not found for id, returns null.
		 * 
		 * @param id
		 *            article id
		 * @return article object for given id
		 */
		public Article get(Long id) {

			for (Article a : articles) {
				if ( a.getId() ==id ) {
					return a;
				}
			}
			return null;
		}
		
		/**
		 * Gets article by date specified
		 * @param date
		 * @return
		 */
		public List<Article> getByDate(LocalDate date){
			List<Article> articlesByDate = new ArrayList<Article>();
			for(Article a : articles) {
				if( a.getDateCreated().getDayOfYear() == date.getDayOfYear()) {
					articlesByDate.add(a);
				}
			}
			return articlesByDate;
		}
		
		/**
		 * Gets article by cal day specified
		 * @param calendar day
		 * @return
		 */
		public List<Article> getByCalDay(int calendarDay){
			List<Article> articlesByDate = new ArrayList<Article>();
			for(Article a : articles) {
				if( a.getDateCreated().getDayOfYear() == calendarDay) {
					articlesByDate.add(a);
				}
			}
			return articlesByDate;
		}

		/**
		 * Create new article in memory. Updates the id and insert new
		 * article in list.
		 * 
		 * @param article
		 *            Article object
		 * @return article object with updated id
		 */
		public Article create(Article article) {
			if(article.getTitle().length() < 64) {
				article.setId(idCounter.incrementAndGet());
				articles.add(article);
				return article;
			}
			return null;
		}

		/**
		 * Delete article object from memory. If article not found for
		 * given id, returns null.
		 * 
		 * @param id
		 *            article id
		 * @return id of deleted article object
		 */
		public Long delete(Long id) {

			for (Article a : articles) {
				if (a.getId() == id ) {
					if(isDateMoreThanAYear(a.getDateCreated())) {
						articles.remove(a);
						return id;
					}
				}
			}

			return null;
		}
		
		/**
		 * checks period for 1 year.
		 * @param articleDate - date of the article was created
		 * @return true if difference more than a year
		 */
		private boolean isDateMoreThanAYear(LocalDate articleDate) {
			if (Period.between(articleDate, LocalDate.now()).getYears() > 1 ) {
				return true;
			}
			return false;
		}

		/**
		 * Update the article object for given id in memory. If article
		 * not exists, returns null. Article can not change ID!!
		 * 
		 * @param id
		 * @param article
		 * @return article object with id
		 */
		public Article update(Long id, Article article) {

			for (Article a : articles) {
				if ( a.getId() == id ) {
					article.setId(a.getId());
					articles.remove(a);
					articles.add(article);
					return article;
				}
			}

			return null;
		}

}
