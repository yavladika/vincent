package com.amdocs;

import java.time.LocalDate;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amdocs.model.Article;
import com.amdocs.model.ArticleDAO;

@RestController
public class ArticleController {

    private static ArticleDAO articleDao = new ArticleDAO();

	/**
	 * getting all existing articles (METHOD GET)
	 * @return
	 */
    @GetMapping("/articles")
    public List<Article> articles() {
        return articleDao.list();
    }
    
    /**
     * getting article by id (METHOD GET)
     * @param id
     * @return
     */
    @GetMapping("/article")
    public Article article(@RequestParam(value="id") long id) {
    	return articleDao.get(id);
    }
    
    /**
     * getting article by date (METHOD GET) (Example: http://localhost:8080/articlebydate?date=2019-08-31)
     * @param date
     * @return
     */
    @GetMapping("/articlebydate")
    public List<Article> articleByDate(@RequestParam(value="date") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate date) {
    	return articleDao.getByDate(date);
    }
    
    /**
     * getting article by calendar day (METHOD GET) (Example: http://localhost:8080/articlebycalday?calday=243)
     * @param date
     * @return
     */
    @GetMapping("/articlebycalday")
    public List<Article> articleByCalDay(@RequestParam(value="calday") int calDay) {
    	return articleDao.getByCalDay(calDay);
    }
    
    /**
     * adding an article (METHOD POST)
     * @param article name
     * 
     * in postman: (Method: POST.) 
     * (Headers Tab: Content-Type:application/json)
     * (Body tab raw in JSON format like {"content": "Serghei New Article added"})
     * @return
     */
    @PostMapping(path="/add_article")
	public ResponseEntity<?> createArticle(@RequestBody Article article) {

    	Article createdArticle = articleDao.create(article);
		if(createdArticle==null) {
			return new ResponseEntity<String>("Could not create article. Check length of the title.", HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Article>(createdArticle, HttpStatus.OK);
	}

    /**
     * DELETE article (METHOD DELETE)
     * @param id
     * @return
     */
	@DeleteMapping("/delete_article/{id}")
	public ResponseEntity<?> deleteArticle(@PathVariable Long id) {
		if (null == articleDao.delete(id)) {
			return new ResponseEntity<String>("The date of the article is less than a year or the article was not found " + id, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Long>(id, HttpStatus.OK);

	}

	/**
	 * Updating article (METHOD PUT)
	 * Article will remain with the same id it had before(id will not be updated)
	 * @param id
	 * @param article
	 * @return
	 */
	@PutMapping("/update_article/{id}")
	public ResponseEntity<?> updateArticle(@PathVariable Long id, @RequestBody Article article) {
		article = articleDao.update(id, article);

		if (null == article) {
			return new ResponseEntity<String>("No Article found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<Article>(article, HttpStatus.OK);
	}
}